# Implemented

## Feature

### Local storage & supabase note synchronization

By keeping user data in both local storage and database, it enables offline note taking as well as prevent data lost (this can happen when closing the app before note being stored in database).

(January 12, 2025)

## UI/UX

